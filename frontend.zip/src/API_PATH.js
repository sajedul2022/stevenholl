// export const API_PATH = 'http://127.0.0.1:8000/api';
// export const MAIN_PATH = 'http://127.0.0.1:8000';

export const API_PATH = 'https://www.inspaceatelier.com/admin/api';
export const MAIN_PATH = 'https://www.inspaceatelier.com/admin';


// http://127.0.0.1:8000/api
// https://www.inspaceatelier.com/admin/api



                                    // USE in any page

// import { API_PATH, MAIN_PATH } from '../API_PATH';

// `${API_PATH}/register.php`


// await axios
// .post(`${API_PATH}/register.php`, formData, {
//   headers: { 'content-type': 'multipart/form-data' },
// })


// image

{/* <img src={`${API_PATH}/assets/images/product/${item.thumbnail}`} alt="shope" /> */}

// src={`${MAIN_PATH}/images/${item.logo}`}