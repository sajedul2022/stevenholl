import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Carousel from "react-bootstrap/Carousel";
import Accordion from "react-bootstrap/Accordion";
import { useNavigate, useParams } from "react-router-dom";
import { API_PATH, MAIN_PATH } from "../API_PATH";

import { Player } from "video-react";

export default function SingleProject() {
  // basic
  const [error, setError] = useState(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [items, setItems] = useState([]);
  console.log(items);

  useEffect(() => {
    fetch(`${API_PATH}/basic-fe`)
      // fetch("https://inspace.bdprogrammers.com/admin/api/basic-fe")
      .then((res) => res.json())
      .then(
        (result) => {
          setIsLoaded(true);
          setItems(result);
        },
        (error) => {
          setIsLoaded(true);
          setError(error);
        }
      );
  }, []);
  // single project

  let params = useParams();
  let navigate = useNavigate();

  const [getuserdata, setUserdata] = useState([]);
  console.log(getuserdata);

  const getdata = async (id) => {
    const res = await fetch(`${API_PATH}/single_project/${id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await res.json();
    console.log(data);

    if (res.status === 422 || !data) {
      console.log("error ");
    } else {
      setUserdata(data);
      console.log("get data");
    }
  };

  useEffect(() => {
    getdata(params.id);
  }, []);

  // No Image

  // const placeholderImage = 'assets/images/uploads/no_image.png'  `${MAIN_PATH}/images/20230521121147.png`
  // const placeholderImage = "images/no_image.png";

  return (
    <>
      <div
        className="bgcommanSec"
        style={{
          // backgroundImage: `url("assets/images/uploads/6.jpg")`,
          // backgroundColor: "#2f4966",
        }}
      ></div>

    

      {items.map((element, id) => {
        return (
          <>
            <div className="fullscreenslider homes-slider ">
              <Carousel variant="light">
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    // src="assets/images/uploads/1.jpg"
                    src={`${MAIN_PATH}/images/${element.image_01}`}
                    alt="First slide"
                  />
                </Carousel.Item>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    // src="assets/images/uploads/2.jpg"
                    src={`${MAIN_PATH}/images/${element.image_02}`}
                    alt="Second slide"
                  />
                  {/* <Carousel.Caption>
              <h5>Second slide label</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </Carousel.Caption> */}
                </Carousel.Item>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    // src="assets/images/uploads/3.jpg"
                    src={`${MAIN_PATH}/images/${element.image_03}`}
                    alt="Third slide"
                  />
                  {/* <Carousel.Caption>
              <h5>Third slide label</h5>
              <p>
                Praesent commodo cursus magna, vel scelerisque nisl consectetur.
              </p>
            </Carousel.Caption> */}
                </Carousel.Item>
              </Carousel>
            </div>
          </>
        );
      })}

      <div className="container">
        <div className="row">
          {/* <div className="col-sm-3 col-md-3 col-lg-3"> </div> */}

          <div className="col-sm-10 col-md-10 col-lg-10 common-bodySec-home  ">

            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>  
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/> 
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            &nbsp; <br/>
            


          </div>

          <div className="col-sm-2 col-md-2 col-lg-2">
            {/* logo and social */}
            {items.map((element, id) => {
              return (
                <>
                  {/* logo */}
                  <div className="h-logo">
                    <Link to="/">
                      <img
                        className="b-logo "
                        // src="assets/images/logo.png"
                        src={`${MAIN_PATH}/images/${element.logo}`}
                        style={{ height: "30px" }}
                        alt="Logo"
                      />
                    </Link>
                  </div>

                  {/* Social */}
                  <div className="h-social">
                    <ul className="social-icon">
                      <li>
                        <Link to={element.facebook} target="_blank">
                          <img src="/assets/images/facebook.svg" alt="" />
                        </Link>
                      </li>
                      <li>
                        <Link to={element.instagram} target="_blank">
                          <img src="/assets/images/instagram.svg" alt="" />
                        </Link>
                      </li>
                      <li>
                        <Link to={element.youtube} target="_blank">
                          <img src="/assets/images/youtube.svg" alt="" />
                        </Link>
                      </li>

                      <li>
                        <Link to={element.linkedin} target="_blank">
                          <img src="/assets/images/linkedin.svg" alt="" />
                        </Link>
                      </li>
                    </ul>
                  </div>
                </>
              );
            })}
            
          </div>
        </div>
      </div>
    </>
  );
}
