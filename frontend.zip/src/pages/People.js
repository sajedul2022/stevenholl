import React, { useEffect, useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import Carousel from "react-bootstrap/Carousel";
import { API_PATH, MAIN_PATH } from "../API_PATH";

export default function People() {

  // basic

  const [error, setError] = useState(null);
const [isLoaded, setIsLoaded] = useState(false);
const [items, setItems] = useState([]);
  console.log(items);

  useEffect(() => {
    fetch(`${API_PATH}/basic-fe`)
      .then((res) => res.json())
      .then(
        (result) => {
          setIsLoaded(true);
          setItems(result);
        },
        (error) => {
          setIsLoaded(true);
          setError(error);
        }
      );
  }, []);

  // People cat
  const [getuserdata, setUserdata] = useState([]);
  console.log(getuserdata);

  const getdata = async () => {
    const res = await fetch(`${API_PATH}/p-cat`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await res.json();
    console.log(data);

    if (res.status === 422 || !data) {
      console.log("error ");
    } else {
      setUserdata(data);
      console.log("get data");
    }
  };

  useEffect(() => {
    getdata();
  }, []);

  // click event
  const [active, setActive] = useState(null);
  
  const [show, setShow] = useState();

  const handleClick = async (id) => {
    try {
      const response = await fetch(`${API_PATH}/cat_people/${id}`);
      // const response = fetch(`https://inspace.bdprogrammers.com/admin/api/cat_project/${id}`);
      const data = await response.json();
      console.log(data);
      setData(data);
    } catch (error) {
      console.log(error);
    }
  };

  const [users, setData] = useState([]);

  // ==============  People  fetch  =========================

  let params = useParams();

  const [getPeople, setPeople] = useState([]);
  console.log(getPeople);

  const getProjectdata = async (id) => {
    const result = await fetch(`${API_PATH}/people-fe`, {
      // const result = await fetch(`${API_PATH}/design-item/${id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const datas = await result.json();
    console.log(datas);

    if (result.status === 422 || !datas) {
      console.log("error ");
    } else {
      setPeople(datas);
      console.log("get datas22");
    }
  };

  useEffect(() => {
    getProjectdata(params.id);
  }, []);

  // return

  return (
    <>
      
      {items.map((item, ids) => {
        return (
          <>
            <div
              className="bgcommanSec fullscreenslider"
              style={{
                backgroundImage: `url(${MAIN_PATH}/images/${item.people_bg_image})`,
                // backgroundColor: "#0000004d",
              }}
            ></div>
          </>
        );
      })};

      <div className="container">
        <div className="row">

          <div className="col-sm-3 col-md-3 col-lg-3 people-menus ">
            <div className="sub-menu ">
              <ul className="menu">
                {getuserdata.map((element, id) => {
                  return (
                    <>
                      <li
                        key={id}
                        item={element}
                        id="menu-item-5915"
                        onClick={() => setActive(element)}
                        className={`${active == element && "menu-active"}`}
                      >
                        
                        <li onClick={() => setShow(true)}>
                          <button onClick={() => handleClick(element.id)}>
                            {element.name}
                          </button>
                        </li>

                        {/* <button>
                          <Link to={`/people/${element.id}`}>
                            {element.name}
                          </Link>
                        </button> */}

                      </li>
                    </>
                  );
                })}
              </ul>
            </div>
          </div>

          <div className="col-sm-7 col-md-7 col-lg-7 common-bodySec people single-people">
            <div className="body-content">
              <div className="row sec-scroll ">
                
                {users.map((item, ids) => {
                  return (
                    <>
                      <div className="col-sm-3 col-md-3 col-lg-3  project-item ">
                        <div className="">
                          <div key={(ids = 1)} item={item} className="">
                            <div className="img-wrap">
                              {/* <Link to={`/single-project/${item.id}`}> */}
                              <Link>
                                <img
                                  src={`${MAIN_PATH}/images/${item.image}`}
                                  alt={item.name}
                                />
                              </Link>
                            </div>

                            <div className="titleSec">
                              <h2>
                                <Link>{item.name}</Link>
                              </h2>
                              <p>{item.description}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })}

                {/* All  */}
                {getPeople.map((item, ids) => {
                  return (
                    <>
                      <div className="col-sm-3 col-md-3 col-lg-3  project-item ">
                        <div className={`${show ? "hidden" : ""}`}  >
                          <div key={(ids = 1)} item={item} className="">
                            <div className="img-wrap">
                              {/* <Link to={`/single-project/${item.id}`}> */}
                              <Link>
                                <img
                                  src={`${MAIN_PATH}/images/${item.image}`}
                                  alt={item.name}
                                /> 
                                
                              </Link>
                            </div>

                            <div className="titleSec">
                              <h2>
                             
                                <Link>{item.name}</Link>
                              </h2>
                              {/* <p>{item.description}</p> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })}

              </div>
            </div>
          </div>

          <div className="col-sm-2 col-md-2 col-lg-2">

                 
{/* logo and social */}
      {items.map((element, id) => {
        return (
          <>
            {/* logo */}
            <div className="h-logo">
              <Link to="/">
                <img
                  className="b-logo "
                  // src="assets/images/logo.png"
                  src={`${MAIN_PATH}/images/${element.logo}`}
                  style={{ height: "30px" }}
                  alt="Logo"
                />
              </Link>
            </div>

            {/* Social */}
            <div className="h-social">
              <ul className="social-icon">
                <li>
                  <Link to={element.facebook} target="_blank">
                    <img src="/assets/images/facebook.svg" alt="" />
                  </Link>
                </li>
                <li>
                  <Link to={element.instagram} target="_blank">
                    <img src="/assets/images/instagram.svg" alt="" />
                  </Link>
                </li>
                <li>
                  <Link to={element.youtube} target="_blank">
                    <img src="/assets/images/youtube.svg" alt="" />
                  </Link>
                </li>

                <li>
                  <Link to={element.linkedin} target="_blank">
                    <img src="/assets/images/linkedin.svg" alt="" />
                  </Link>
                </li>
              </ul>
            </div>
          </>
        );
      })}
      
          </div> 
          
        </div>
      </div>
    </>
  );
}
