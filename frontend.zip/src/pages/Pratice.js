import React, { useEffect, useState } from "react";
import { Link, NavLink, useLocation, useParams } from "react-router-dom";
import Carousel from "react-bootstrap/Carousel";
import { API_PATH, MAIN_PATH } from "../API_PATH";

export default function Pratice() {

// basic

const [error, setError] = useState(null);
const [isLoaded, setIsLoaded] = useState(false);
const [items, setItems] = useState([]);
  console.log(items);

  useEffect(() => {
    fetch(`${API_PATH}/basic-fe`)
      .then((res) => res.json())
      .then(
        (result) => {
          setIsLoaded(true);
          setItems(result);
        },
        (error) => {
          setIsLoaded(true);
          setError(error);
        }
      );
  }, []);

  // use effect

  const [getOfficedata, setOfficedata] = useState([]);
  const getoffice = async () => {
    const res = await fetch(`${API_PATH}/office-fe`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await res.json();
    console.log(data);

    if (res.status === 422 || !data) {
      console.log("error ");
    } else {
      setOfficedata(data);
      console.log("get data");
    }
  };

  useEffect(() => {
    getoffice();
  }, []);

  // about

  const [getAboutdata, setAboutdata] = useState([]);
  const getabout = async () => {
    const res = await fetch(`${API_PATH}/about-fe`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await res.json();
    console.log(data);

    if (res.status === 422 || !data) {
      console.log("error ");
    } else {
      setAboutdata(data);
      console.log("get data");
    }
  };

  useEffect(() => {
    getabout();
  }, []);

  // history

  const [gethistorydata, setHistorydata] = useState([]);
  const gethistory = async () => {
    const res = await fetch(`${API_PATH}/history-fe`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await res.json();
    console.log(data);

    if (res.status === 422 || !data) {
      console.log("error ");
    } else {
      setHistorydata(data);
      console.log("get data");
    }
  };

  useEffect(() => {
    gethistory();
  }, []);

  // About click event
  const [toggle, setToggle] = useState(true);

  const handleClickAbout = async () => {
    setToggle(!toggle);
    try {
      const response = await fetch(`${API_PATH}/about-fe`);
      // const response = fetch(`https://inspace.bdprogrammers.com/admin/api/cat_project/${id}`);
      const data = await response.json();
      console.log(data);
      setabout(data);
    } catch (error) {
      console.log(error);
    }
  };

  const [about, setabout] = useState([]);

  //   Office  click event

  const handleClickOffice = async () => {
    setToggle(!toggle);

    try {
      const response = await fetch(`${API_PATH}/office-fe`);
      // const response = fetch(`https://inspace.bdprogrammers.com/admin/api/cat_project/${id}`);
      const data = await response.json();
      console.log(data);
      setOffice(data);
    } catch (error) {
      console.log(error);
    }
  };

  const [Office, setOffice] = useState([]);

  //   History  click event

  const handleClickHistory = async () => {
    setToggle(!toggle);
    try {
      const response = await fetch(`${API_PATH}/history-fe`);
      // const response = fetch(`https://inspace.bdprogrammers.com/admin/api/cat_project/${id}`);
      const data = await response.json();
      console.log(data);
      setHistory(data);
    } catch (error) {
      console.log(error);
    }
  };

  const [History, setHistory] = useState([]);

  // return

  return (
    <>
      {items.map((item, ids) => {
        return (
          <>
            <div
              className="bgcommanSec fullscreenslider"
              style={{
                backgroundImage: `url(${MAIN_PATH}/images/${item.practice_bg_image})`,
                // backgroundColor: "#0000004d",
              }}
            ></div>
          </>
        );
      })};

      <div className="container">
        <div className="row">

          <div className="col-sm-3 col-md-3 col-lg-3 pratice-menus">

            <div className="sub-menu">
              <ul className="menu pratice-menu">
                <li id="menu-item-5915">
                  <button>
                    <NavLink exact activeClassName="active" to="/about">
                      About
                    </NavLink>
                  </button>
                </li>

                <li id="menu-item-5915">
                  <button>
                    <NavLink activeClassName="active" to="/office">
                      Office
                    </NavLink>
                  </button>
                </li>

                <li id="menu-item-5915">
                  <button>
                    <NavLink activeClassName="active" to="/history">
                      History
                    </NavLink>
                  </button>
                </li>

                {/* <li>
                  <button onClick={() => handleClickAbout()}>ABOUT US</button>
                </li>

                <li>
                  <button onClick={() => handleClickOffice()}>OFFICE</button>
                </li>

                <li>
                  <button onClick={() => handleClickHistory()}>HISTORY</button>
                </li> */}
              </ul>
            </div>
          </div>

          <div className="col-sm-7 col-md-7 col-lg-7 common-bodySec ">
            {/* <div className="pratice-content pratice "> */}
            <div className=" ">
              <div className="row sec-scroll">
                {/* About */}
                {getAboutdata.map((item, ids) => {
                  return (
                    <>
                      <div className="col-sm-12 col-md-12 col-lg-12 ">
                        <div className="sub-paragraph">
                          <h3 className="text-center"> At A Glance </h3>
                        </div>

                        <div className="pratice-sec">
                          <div key={(ids = 1)} item={item} className="">
                            <div className="sub-paragraph ">
                              <h4 className=""> About </h4>
                              <article
                                id="post-5833"
                                className="post-5833 page type-page status-publish has-post-thumbnail hentry"
                              >
                                <div className="entry-content">
                                  <p>{item.short_des}</p>

                                  <p>
                                    <img
                                      src={`${MAIN_PATH}/images/${item.image}`}
                                      alt={item.short_des}
                                    />
                                    {item.full_des}
                                  </p>

                                  <hr />
                                </div>
                              </article>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })}

                {/* Office */}
                {getOfficedata.map((item, ids) => {
                  return (
                    <>
                      <div className="col-sm-12 col-md-12 col-lg-12 office">
                        <div className="">
                          <div key={(ids = 1)} item={item} className="">
                            <div className="sub-paragraph ">
                              <h4 className=""> Office </h4>
                              <article
                                id="post-5833"
                                className="post-5833 page type-page status-publish has-post-thumbnail hentry"
                              >
                                <div className="entry-content">
                                  <p>{item.short_des}</p>

                                  <p>
                                    <img
                                      src={`${MAIN_PATH}/images/${item.image}`}
                                      alt={item.short_des}
                                    />
                                    {item.full_des}
                                  </p>

                                  <hr />
                                </div>
                              </article>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })}

                {/* History */}
                <div className="col-sm-12 col-md-12 col-lg-12 office">
                  <div className="sub-paragraph   ">
                    <h4 className=""> Office </h4>
                  </div>
                </div>
                <div className="row">
                  {gethistorydata.map((item, ids) => {
                    return (
                      <>
                        <div className="col-sm-4 col-md-4 col-lg-4 history-all ">
                          <div className="sub-paragraph">
                            <div key={(ids = 1)} item={item} className="">
                              <div className="img-wrap">
                                <img
                                  src={`${MAIN_PATH}/images/${item.image}`}
                                  alt={item.title}
                                />
                              </div>
                              <br />

                              <div className="titleSec">
                                <h2>
                                  {" "}
                                  <br /> {item.year}
                                </h2>
                              </div>

                              <div className="titleSec">
                                <b>
                                  <h2>{item.title}</h2>
                                </b>
                              </div>

                              <p>{item.full_des}</p>
                            </div>
                          </div>
                        </div>
                      </>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          <div className="col-sm-2 col-md-2 col-lg-2">

                 
{/* logo and social */}
      {items.map((element, id) => {
        return (
          <>
            {/* logo */}
            <div className="h-logo">
              <Link to="/">
                <img
                  className="b-logo "
                  // src="assets/images/logo.png"
                  src={`${MAIN_PATH}/images/${element.logo}`}
                  style={{ height: "30px" }}
                  alt="Logo"
                />
              </Link>
            </div>

            {/* Social */}
            <div className="h-social">
              <ul className="social-icon">
                <li>
                  <Link to={element.facebook} target="_blank">
                    <img src="/assets/images/facebook.svg" alt="" />
                  </Link>
                </li>
                <li>
                  <Link to={element.instagram} target="_blank">
                    <img src="/assets/images/instagram.svg" alt="" />
                  </Link>
                </li>
                <li>
                  <Link to={element.youtube} target="_blank">
                    <img src="/assets/images/youtube.svg" alt="" />
                  </Link>
                </li>

                <li>
                  <Link to={element.linkedin} target="_blank">
                    <img src="/assets/images/linkedin.svg" alt="" />
                  </Link>
                </li>
              </ul>
            </div>
          </>
        );
      })}
          </div> 

        </div>
      </div>
    </>
  );
}
