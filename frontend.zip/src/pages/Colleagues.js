import React, { useEffect, useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import { API_PATH, MAIN_PATH } from "../API_PATH";

export default function Colleagues() {
  // basic

  const [error, setError] = useState(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [items, setItems] = useState([]);
  console.log(items);

  useEffect(() => {
    fetch(`${API_PATH}/basic-fe`)
      .then((res) => res.json())
      .then(
        (result) => {
          setIsLoaded(true);
          setItems(result);
        },
        (error) => {
          setIsLoaded(true);
          setError(error);
        }
      );
  }, []);

  // cat design
  const [getuserdata, setUserdata] = useState([]);
  console.log(getuserdata);

  const getdata = async () => {
    const res = await fetch(`${API_PATH}/colleagues-fe`, {
      // const res = await fetch("https://inspace.bdprogrammers.com/admin/api/const-cat", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await res.json();
    console.log(data);

    if (res.status === 422 || !data) {
      console.log("error ");
    } else {
      setUserdata(data);
      console.log("get data");
    }
  };

  useEffect(() => {
    getdata();
  }, []);

  // return

  return (
    <>
      {items.map((item, ids) => {
        return (
          <>
            <div
              className="bgcommanSec fullscreenslider"
              style={{
                backgroundImage: `url(${MAIN_PATH}/images/${item.colleagues_bg_image})`,
                // backgroundColor: "#0000004d",
              }}
            ></div>
          </>
        );
      })}
      ;
      <div className="container">
        <div className="row">
          <div className="col-sm-3 col-md-3 col-lg-3">
            <div className="sub-menu">
              <ul className="menu">
                <li></li>
              </ul>
            </div>
          </div>

          <div className="col-sm-7 col-md-7 col-lg-7 collegues common-bodySec ">
            <div className="body-content ">
              <div className="row sec-scroll">
                {getuserdata.map((item, ids) => {
                  return (
                    <>
                      <div className="col-sm-12 col-md-12 col-lg-12 ">
                        <div className="">
                          <div key={(ids = 1)} item={item} className="">
                            <div className="sub-paragraph">
                              <article
                                id="post-5833"
                                className="post-5833 page type-page status-publish has-post-thumbnail hentry"
                              >
                                <div className="entry-content">
                                  <h4>{item.title}</h4>

                                  {/* <img
                                    src={`${MAIN_PATH}/images/${item.image}`}
                                    // src="http://127.0.0.1:8000/images/20230410072328.jpg"
                                    alt={item.name}
                                  /> */}
                                  <p>
                                    <b>vacancy: </b> <br />
                                    {item.vacancy}
                                  </p>
                                  <p>
                                    <b>Job context: </b> <br />
                                    {item.context}
                                  </p>

                                  <div className="row">
                                    <div className="col-sm-8 col-md-8 col-lg-8 ">
                                      <p>
                                        <b>Responsibilities: </b> <br />
                                        {item.responsibilities}
                                      </p>

                                      <p>
                                        <b>Education: </b> <br />
                                        {item.education}
                                      </p>

                                      <p>
                                        <b>Salary: </b> <br />
                                        {item.salary}
                                      </p>
                                    </div>

                                    <div className="col-sm-4 col-md-4 col-lg-4 ">
                                      <p>
                                        <b>Requirements: </b> <br />
                                        {item.requirements}
                                      </p>
                                    </div>
                                  </div>

                                  <hr />
                                  <p>
                                    <span>
                                      {" "}
                                      Mail your CV: {item.others} <br></br>
                                      OR Apply Google Form:
                                      <Link to={item.g_form} target="_blank">
                                        {" "}
                                        {item.g_form}{" "}
                                      </Link>
                                    </span>{" "}
                                  </p>
                                </div>
                              </article>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="col-sm-2 col-md-2 col-lg-2">
            {/* logo and social */}
            {items.map((element, id) => {
              return (
                <>
                  {/* logo */}
                  <div className="h-logo">
                    <Link to="/">
                      <img
                        className="b-logo "
                        // src="assets/images/logo.png"
                        src={`${MAIN_PATH}/images/${element.logo}`}
                        style={{ height: "30px" }}
                        alt="Logo"
                      />
                    </Link>
                  </div>

                  {/* Social */}
                  <div className="h-social">
                    <ul className="social-icon">
                      <li>
                        <Link to={element.facebook} target="_blank">
                          <img src="/assets/images/facebook.svg" alt="" />
                        </Link>
                      </li>
                      <li>
                        <Link to={element.instagram} target="_blank">
                          <img src="/assets/images/instagram.svg" alt="" />
                        </Link>
                      </li>
                      <li>
                        <Link to={element.youtube} target="_blank">
                          <img src="/assets/images/youtube.svg" alt="" />
                        </Link>
                      </li>

                      <li>
                        <Link to={element.linkedin} target="_blank">
                          <img src="/assets/images/linkedin.svg" alt="" />
                        </Link>
                      </li>
                    </ul>
                  </div>
                </>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
