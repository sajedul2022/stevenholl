import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Carousel from "react-bootstrap/Carousel";
import Accordion from "react-bootstrap/Accordion";
import { useNavigate, useParams } from "react-router-dom";
import { API_PATH, MAIN_PATH } from "../API_PATH";
import { Player } from "video-react";

export default function SingleProject() {
  // basic
  const [error, setError] = useState(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [items, setItems] = useState([]);
  console.log(items);

  useEffect(() => {
    fetch(`${API_PATH}/basic-fe`)
      // fetch("https://inspace.bdprogrammers.com/admin/api/basic-fe")
      .then((res) => res.json())
      .then(
        (result) => {
          setIsLoaded(true);
          setItems(result);
        },
        (error) => {
          setIsLoaded(true);
          setError(error);
        }
      );
  }, []);
  // single project

  let params = useParams();
  let navigate = useNavigate();

  const [getuserdata, setUserdata] = useState([]);
  console.log(getuserdata);

  const getdata = async (id) => {
    const res = await fetch(`${API_PATH}/single_project/${id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await res.json();
    console.log(data);

    if (res.status === 422 || !data) {
      console.log("error ");
    } else {
      setUserdata(data);
      console.log("get data");
    }
  };

  useEffect(() => {
    getdata(params.id);
  }, []);

  // No Image

  // const placeholderImage = 'assets/images/uploads/no_image.png'  `${MAIN_PATH}/images/20230521121147.png`
  // const placeholderImage = "images/no_image.png";

  return (
    <>
      <div
        className="bgcommanSec"
        style={{
          // backgroundImage: `url("assets/images/uploads/6.jpg")`,
          backgroundColor: "#2f4966",
        }}
      ></div>

      {getuserdata.map((element, id) => {
        return (
          <>
            <div className="fullscreenslider single-carousel-out ">
              <div className=" ">
                <div className="">
                  <Carousel variant="light">
                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        // src="assets/images/uploads/4.jpg"
                        src={`${MAIN_PATH}/images/${element.image_01}`}
                        alt="First slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        // src="assets/images/uploads/2.jpg"
                        src={`${MAIN_PATH}/images/${element.image_02}`}
                        alt="Second slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        // src="assets/images/uploads/3.jpg"
                        src={`${MAIN_PATH}/images/${element.image_03}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>
                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        // src="assets/images/uploads/3.jpg"
                        src={`${MAIN_PATH}/images/${element.image_04}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        // src="assets/images/uploads/3.jpg"
                        src={`${MAIN_PATH}/images/${element.image_05}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_06}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_07}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_08}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_09}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_10}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_11}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_12}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_13}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_14}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_15}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_16}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_17}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_18}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_19}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_20}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_21}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_22}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_23}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_24}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_25}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_26}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_27}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_28}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_29}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_30}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_31}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_32}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_33}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_34}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_35}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_36}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_37}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_38}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_39}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_40}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_41}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_42}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_43}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_44}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_45}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_46}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_47}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_48}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_49}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>

                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src={`${MAIN_PATH}/images/${element.image_50}`}
                        alt="Third slide"
                      />
                    </Carousel.Item>
                  </Carousel>
                </div>
              </div>
            </div>
          </>
        );
      })}

      <div className="container">
        <div className="row">
          {/* <div className="col-sm-3 col-md-3 col-lg-3"> </div> */}

          <div className="col-sm-10 col-md-10 col-lg-10 ">
            {/* <div className="col-sm-7 col-md-7 col-lg-7"> */}

            {/* <div className="paragraph-section container single-project"> */}
            <div className="single-project">
              <div className="row sec-scroll">
                {getuserdata.map((element, id) => {
                  return (
                    <>
                      <div className="col-sm-5 col-md-5 col-lg-5">
                        <div>
                          <div className="sub-paragraph">
                            <div>
                              <h5> Title: {element.name} </h5>
                              <hr />
                            </div>

                            <div>
                              <b>
                                <h5> Description: </h5>{" "}
                              </b>
                              <p>{element.description} </p>
                            </div>
                          </div>

                          {/* <Accordion>
                            <Accordion.Item eventKey="0">
                              <Accordion.Header> Watch Video &nbsp; <i class="fa fa-play"></i>  </Accordion.Header>
                              <Accordion.Body>
                                <Player
                                  className=""
                                  playsInline
                                  poster="/assets/images/uploads/6.jpg"
                                  src={`${MAIN_PATH}/${element.video}`}
                                />
                              </Accordion.Body>
                            </Accordion.Item>

                            <Accordion.Item eventKey="1">
                                  <Accordion.Header>
                                    Ecological Innovation
                                  </Accordion.Header>
                                  <Accordion.Body>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing
                                    elit, sed do eiusmod tempor incididunt ut labore et
                                    dolore magna aliqua. Ut enim ad minim veniam, quis
                                    nostrud exercitation ullamco laboris nisi ut aliquip
                                    ex ea commodo consequat. Duis aute irure dolor in
                                    reprehenderit in voluptate velit esse cillum dolore eu
                                    fugiat nulla pariatur. Excepteur sint occaecat
                                    cupidatat non proident, sunt in culpa qui officia
                                    deserunt mollit anim id est laborum.
                                  </Accordion.Body>
                                  </Accordion.Item> 

                             <Accordion.Item eventKey="2">
                              <Accordion.Header>Videos</Accordion.Header>
                              <Accordion.Body>
                                Watch Videos: 
                                <script>let video = {element.video}</script>
                                <Player
                                  playsInline
                                  poster="/assets/poster.png"
                                  
                                  src="https://media.w3.org/2010/05/sintel/trailer_hd.mp4"
                                />

                                  <video width="100%" controls id="myvideo">
                                    <source src={element.video} type="video/mp4"/>
                                    Your browser does  not support the video tag.
                                  </video>

                              </Accordion.Body>
                            </Accordion.Item> 

                             <Accordion.Item eventKey="3">
                              <Accordion.Header>Credits</Accordion.Header>
                              <Accordion.Body>{element.credits}</Accordion.Body>
                            </Accordion.Item>

                            <Accordion.Item eventKey="4">
                              <Accordion.Header>Quotes</Accordion.Header>
                              <Accordion.Body>{element.quotes}</Accordion.Body>
                            </Accordion.Item>

                            <Accordion.Item eventKey="5">
                              <Accordion.Header>News</Accordion.Header>
                              <Accordion.Body>{element.news}</Accordion.Body>
                            </Accordion.Item>

                            <Accordion.Item eventKey="6">
                              <Accordion.Header>Awards</Accordion.Header>
                              <Accordion.Body>{element.awards}</Accordion.Body>
                            </Accordion.Item>

                            <Accordion.Item>
                              <Accordion.Header>
                                <Link to={element.link}>More Relevant Works</Link>
                              </Accordion.Header>
                            </Accordion.Item>
                            
                          </Accordion> */}
                        </div>
                      </div>

                      <div className=" col-sm-7 col-md-7 col-lg-7 body-content">
                        {/* video  */}

                        <Accordion>
                          <Accordion.Item eventKey="0">
                            <Accordion.Header>
                              {" "}
                              Watch Video &nbsp; <i class="fa fa-play"></i>{" "}
                            </Accordion.Header>
                            <Accordion.Body>
                              <Player
                                className=""
                                playsInline
                                poster="/assets/images/uploads/6.jpg"
                                src={`${MAIN_PATH}/${element.video}`}
                              />
                            </Accordion.Body>
                          </Accordion.Item>
                        </Accordion>


                       


                        <div className="single-carousel-in">
                          <Carousel
                            variant="dark"
                            // className="carousel-container"
                          >
                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                // src="assets/images/uploads/4.jpg"
                                src={`${MAIN_PATH}/images/${element.image_01}`}
                                alt="First slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                // src="assets/images/uploads/2.jpg"
                                src={`${MAIN_PATH}/images/${element.image_02}`}
                                alt="Second slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_03}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                // src="assets/images/uploads/3.jpg"
                                src={`${MAIN_PATH}/images/${element.image_04}`}
                                alt="Third slide"
                              />
                              {/* <Carousel.Caption>
                          <h5>Third slide label</h5>
                          <p>
                            Praesent commodo cursus magna, vel scelerisque nisl
                            consectetur.
                          </p>
                        </Carousel.Caption> */}
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                // src="assets/images/uploads/3.jpg"
                                src={`${MAIN_PATH}/images/${element.image_05}`}
                                alt="Third slide"
                              />
                              {/* <Carousel.Caption>
                          <h5>Third slide label</h5>
                          <p>
                            Praesent commodo cursus magna, vel scelerisque nisl
                            consectetur.
                          </p>
                        </Carousel.Caption> */}
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_06}`}
                                alt="Works slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_07}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_08}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_09}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_10}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_11}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_12}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_13}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_14}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_15}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_16}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_17}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_18}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_19}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_20}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_21}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_22}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_23}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_24}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_25}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_26}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_27}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_28}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_29}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_30}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_31}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_32}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_33}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_34}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_35}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_36}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_37}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_38}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_39}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_40}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_41}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_42}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_43}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_44}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_45}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_46}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_47}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_48}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_49}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>

                            <Carousel.Item>
                              <img
                                className="d-block w-100"
                                src={`${MAIN_PATH}/images/${element.image_50}`}
                                alt="Third slide"
                              />
                            </Carousel.Item>
                          </Carousel>
                        </div>
                      </div>
                    </>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="col-sm-2 col-md-2 col-lg-2">
            {/* logo and social */}
            {items.map((element, id) => {
              return (
                <>
                  {/* logo */}
                  <div className="h-logo">
                    <Link to="/">
                      <img
                        className="b-logo "
                        // src="assets/images/logo.png"
                        src={`${MAIN_PATH}/images/${element.logo}`}
                        style={{ height: "30px" }}
                        alt="Logo"
                      />
                    </Link>
                  </div>

                  {/* Social */}
                  <div className="h-social">
                    <ul className="social-icon">
                      <li>
                        <Link to={element.facebook} target="_blank">
                          <img src="/assets/images/facebook.svg" alt="" />
                        </Link>
                      </li>
                      <li>
                        <Link to={element.instagram} target="_blank">
                          <img src="/assets/images/instagram.svg" alt="" />
                        </Link>
                      </li>
                      <li>
                        <Link to={element.youtube} target="_blank">
                          <img src="/assets/images/youtube.svg" alt="" />
                        </Link>
                      </li>

                      <li>
                        <Link to={element.linkedin} target="_blank">
                          <img src="/assets/images/linkedin.svg" alt="" />
                        </Link>
                      </li>
                    </ul>
                  </div>
                </>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
