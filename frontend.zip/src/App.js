import { Outlet } from "react-router-dom";
import "./App.css";
import Header from "./components/Header1";
import Footer from "./components/Footer";
import "./../node_modules/video-react/dist/video-react.css";

// import Header2 from "./components/Header2";
// import HomeSlider from "./components/HomeSlider";


function App() {
  return (
    <>
      
        {/* <Header /> */}
        {/* <Header2 /> */}

        {/* <HomeSlider/> */}

        <Outlet />

        <Footer />
      
    </>
  );
}

export default App;
