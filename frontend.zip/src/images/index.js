const IMAGES = {
    imgFav: require('./favicon.png'),
    imgArrow: require('./nav-arrow.png'),
}

export default IMAGES;