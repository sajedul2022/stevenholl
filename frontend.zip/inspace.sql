-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2023 at 08:29 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inspace`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `short_des` text DEFAULT NULL,
  `full_des` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `bg_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `short_des`, `full_des`, `image`, `bg_image`, `created_at`, `updated_at`) VALUES
(1, 'In 2022, Today\'s architecture is focused on sustainability, human well-being, and adaptability. Energy-efficient and environmentally-friendly designs, humancentric spaces, and flexible structures that can adapt to changing needs are prevalent trends. adaptability. Energy-efficient and environmentally-friendly designs, human-centric spaces, and flexible structures that can adapt to changing needs are prevalent trends.', 'In 2022, Today\'s architecture is focused on sustainability, human well-being, and adaptability. Energy-efficient and environmentally-friendly designs, humancentric spaces, and flexible structures that can adapt to changing needs are prevalent trends. adaptability. Energy-efficient and environmentally-friendly designs, human-centric spaces, and flexible structures that can adapt to changing needs are prevalent trends.In 2022, Today\'s architecture is focused on sustainability, human well-being, and adaptability. Energy-efficient and environmentally-friendly designs, humancentric spaces, and flexible structures that can adapt to changing needs are prevalent trends. adaptability. Energy-efficient and environmentally-friendly designs, human-centric spaces, and flexible structures that can adapt to changing needs are prevalent trends.', '20230521181601.jpg', NULL, '2023-05-21 12:16:01', '2023-05-21 12:16:01');

-- --------------------------------------------------------

--
-- Table structure for table `basics`
--

CREATE TABLE `basics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `m_logo` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `image_01` varchar(255) DEFAULT NULL,
  `image_02` varchar(255) DEFAULT NULL,
  `image_03` varchar(255) DEFAULT NULL,
  `work_bg_image` varchar(200) DEFAULT NULL,
  `people_bg_image` varchar(255) DEFAULT NULL,
  `practice_bg_image` varchar(255) DEFAULT NULL,
  `colleagues_bg_image` varchar(255) DEFAULT NULL,
  `contact_bg_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `basics`
--

INSERT INTO `basics` (`id`, `brand`, `logo`, `m_logo`, `address`, `phone`, `email`, `facebook`, `instagram`, `linkedin`, `youtube`, `image_01`, `image_02`, `image_03`, `work_bg_image`, `people_bg_image`, `practice_bg_image`, `colleagues_bg_image`, `contact_bg_image`, `created_at`, `updated_at`) VALUES
(1, 'INSPACE ATELIER Company', '20230520091136.png', '05202320174234.jpg', 'House# 14/B, Rashid Nibash, Third Floor, Road 68, Gulshan 02, Dhaka 1212', '+880168563633', 'inspaceatelier@gmail.com', 'https://www.facebook.com/people/INSPACE-atelier/100063651129146/', 'https://www.instagram.com/', 'https://www.linkedin.com/', 'http://youtube.com/', '20230520091214.jpg', '0520091046.jpg', '20091136.png', '20163221052023.jfif', '2017025705.avif', '20163221052023.jfif', '20163221202305.avif', '20175320234905.avif', '2023-05-20 03:10:46', '2023-05-20 11:53:49');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Architecture', '2023-05-20 03:18:24', '2023-05-20 03:18:24'),
(2, 'Construction', '2023-05-20 03:18:52', '2023-05-20 03:18:52'),
(3, 'Landscape Design', '2023-05-20 03:19:18', '2023-05-20 03:19:18'),
(4, 'Interior Design', '2023-05-20 03:19:57', '2023-05-20 03:19:57'),
(5, 'Product Design', '2023-05-20 03:20:22', '2023-05-20 03:20:22'),
(6, 'Project Management', '2023-05-20 03:20:45', '2023-05-20 03:20:45');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `histories`
--

CREATE TABLE `histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` text DEFAULT NULL,
  `year` text DEFAULT NULL,
  `full_des` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `bg_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `histories`
--

INSERT INTO `histories` (`id`, `title`, `year`, `full_des`, `image`, `bg_image`, `created_at`, `updated_at`) VALUES
(1, 'Today\'s architecture is focused on sustainability, human well-being, and adaptability.', '2019', 'Furthermore, there is a trend towards designing adaptable and flexible spaces that can easily accommodate changing needs and usage patterns over time.', '20230521181720.jfif', NULL, '2023-05-21 12:17:20', '2023-05-21 12:17:20'),
(2, 'Easily accommodate changing needs and usage patterns over time.', '2020', 'Furthermore, there is a trend toward designing adaptable and flexible spaces that can easily accommodate changing needs and usage patterns over time.', '20230521181847.png', NULL, '2023-05-21 12:17:54', '2023-05-21 12:19:09'),
(3, 'Flexible spaces that can easily accommodate changing needs and usage patterns over time.', '2021', 'Furthermore, there is a trend towards designing adaptable and flexible spaces that can easily accommodate changing needs and usage patterns over time.', '20230521181822.jpg', NULL, '2023-05-21 12:17:58', '2023-05-21 12:18:22');

-- --------------------------------------------------------

--
-- Table structure for table `ideas`
--

CREATE TABLE `ideas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `bg_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ideas`
--

INSERT INTO `ideas` (`id`, `cat_id`, `name`, `description`, `image`, `bg_image`, `created_at`, `updated_at`) VALUES
(1, 2, 'Nahidul Islam', 'SULAIMAN', '20230520180159.png', NULL, '2023-05-20 12:01:59', '2023-05-20 12:09:31'),
(2, 5, 'Nahidul Islam', 'Nahidul Islam', '20230520180903.png', NULL, '2023-05-20 12:09:03', '2023-05-20 12:09:03');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_03_25_074232_create_basics_table', 1),
(7, '2023_03_25_074251_create_ideas_table', 1),
(8, '2023_03_25_074257_create_news_table', 1),
(9, '2023_03_25_074303_create_categories_table', 1),
(10, '2023_03_25_074315_create_projects_table', 1),
(11, '2023_04_11_110025_create_peoplecats_table', 1),
(12, '2023_04_11_110107_create_abouts_table', 1),
(13, '2023_04_11_110113_create_offices_table', 1),
(14, '2023_04_11_110118_create_histories_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `vacancy` varchar(255) DEFAULT NULL,
  `context` text DEFAULT NULL,
  `responsibilities` text DEFAULT NULL,
  `education` text DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `salary` text DEFAULT NULL,
  `others` text DEFAULT NULL,
  `g_form` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `bg_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `vacancy`, `context`, `responsibilities`, `education`, `requirements`, `salary`, `others`, `g_form`, `image`, `bg_image`, `created_at`, `updated_at`) VALUES
(1, 'Intern Architect', '02', 'The packaging industry is growing very fast with its own specialized paper products, such as corrugated master cartons, inner boxes, stickers, paper tubes, etc. To maintain sustainable growth, we are looking for some young, dynamic, and energetic person.', 'Responsible for maintaining general ledger & registers related to finance and accounts. Maintaining company\'s financial transactions, posting in ledger. Work on stock inventory. Maintaining Customer & supplier payment and adjustment. Bank reconciliation statement.', 'Masters in Accounting from any reputed University.', 'Age 25 to 35 years Good communication, both verbal and written. Ability to work under pressure. Must have computer knowledge. Self-motivated and dynamic. Well conversant with MS Office& Accounting Software. Smooth in TALLY software operation.', 'Negotiable', 'inspaceatelier@gmail.com', 'https://docs.google.com/document/u/0/?pli=1', '20230521182117.png', NULL, '2023-05-21 12:21:17', '2023-05-21 12:22:25');

-- --------------------------------------------------------

--
-- Table structure for table `offices`
--

CREATE TABLE `offices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `short_des` text DEFAULT NULL,
  `full_des` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `bg_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `offices`
--

INSERT INTO `offices` (`id`, `short_des`, `full_des`, `image`, `bg_image`, `created_at`, `updated_at`) VALUES
(1, 'In 2022, Today\'s architecture is focused on sustainability, human well-being, and adaptability. Energy-efficient and environmentally-friendly designs, humancentric spaces, and flexible structures that can adapt to changing needs are prevalent trends. adaptability. Energy-efficient and environmentally-friendly designs, human-centric spaces, and flexible structures that can adapt to changing needs are prevalent trends.', 'In 2022, Today\'s architecture is focused on sustainability, human well-being, and adaptability. Energy-efficient and environmentally-friendly designs, humancentric spaces, and flexible structures that can adapt to changing needs are prevalent trends. adaptability. Energy-efficient and environmentally-friendly designs, human-centric spaces, and flexible structures that can adapt to changing needs are prevalent trends.In 2022, Today\'s architecture is focused on sustainability, human well-being, and adaptability. Energy-efficient and environmentally-friendly designs, humancentric spaces, and flexible structures that can adapt to changing needs are prevalent trends. adaptability. Energy-efficient and environmentally-friendly designs, human-centric spaces, and flexible structures that can adapt to changing needs are prevalent trends.', '20230521181639.png', NULL, '2023-05-21 12:16:39', '2023-05-21 12:16:39');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `peoplecats`
--

CREATE TABLE `peoplecats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `peoplecats`
--

INSERT INTO `peoplecats` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Principal', '2023-05-20 03:24:33', '2023-05-20 03:24:33'),
(2, 'Architecture', '2023-05-20 03:24:49', '2023-05-20 03:24:49'),
(3, 'Structure Engineer', '2023-05-20 03:25:02', '2023-05-20 03:25:02'),
(4, 'Site Engineer', '2023-05-20 03:25:11', '2023-05-20 03:25:11'),
(5, 'Interior', '2023-05-20 03:25:27', '2023-05-20 03:25:27'),
(6, 'HR Admin', '2023-05-20 03:25:39', '2023-05-20 03:25:39'),
(7, 'Others', '2023-05-20 03:25:53', '2023-05-20 03:25:53');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `video` varchar(255) DEFAULT NULL,
  `credits` varchar(255) DEFAULT NULL,
  `quotes` varchar(255) DEFAULT NULL,
  `news` varchar(255) DEFAULT NULL,
  `awards` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `image_01` varchar(255) DEFAULT NULL,
  `image_02` varchar(255) DEFAULT NULL,
  `image_03` varchar(255) DEFAULT NULL,
  `image_04` varchar(255) DEFAULT NULL,
  `image_05` varchar(255) DEFAULT NULL,
  `image_06` varchar(255) DEFAULT NULL,
  `image_07` varchar(255) DEFAULT NULL,
  `image_08` varchar(255) DEFAULT NULL,
  `image_09` varchar(255) DEFAULT NULL,
  `image_10` varchar(255) DEFAULT NULL,
  `image_11` varchar(255) DEFAULT NULL,
  `image_12` varchar(255) DEFAULT NULL,
  `image_13` varchar(255) DEFAULT NULL,
  `image_14` varchar(255) DEFAULT NULL,
  `image_15` varchar(255) DEFAULT NULL,
  `image_16` varchar(255) DEFAULT NULL,
  `image_17` varchar(255) DEFAULT NULL,
  `image_18` varchar(255) DEFAULT NULL,
  `image_19` varchar(255) DEFAULT NULL,
  `image_20` varchar(255) DEFAULT NULL,
  `image_21` varchar(255) DEFAULT NULL,
  `image_22` varchar(255) DEFAULT NULL,
  `image_23` varchar(255) DEFAULT NULL,
  `image_24` varchar(255) DEFAULT NULL,
  `image_25` varchar(255) DEFAULT NULL,
  `image_26` varchar(255) DEFAULT NULL,
  `image_27` varchar(255) DEFAULT NULL,
  `image_28` varchar(255) DEFAULT NULL,
  `image_29` varchar(255) DEFAULT NULL,
  `image_30` varchar(255) DEFAULT NULL,
  `image_31` varchar(255) DEFAULT NULL,
  `image_32` varchar(255) DEFAULT NULL,
  `image_33` varchar(255) DEFAULT NULL,
  `image_34` varchar(255) DEFAULT NULL,
  `image_35` varchar(255) DEFAULT NULL,
  `image_36` varchar(255) DEFAULT NULL,
  `image_37` varchar(255) DEFAULT NULL,
  `image_38` varchar(255) DEFAULT NULL,
  `image_39` varchar(255) DEFAULT NULL,
  `image_40` varchar(255) DEFAULT NULL,
  `image_41` varchar(255) DEFAULT NULL,
  `image_42` varchar(255) DEFAULT NULL,
  `image_43` varchar(255) DEFAULT NULL,
  `image_44` varchar(255) DEFAULT NULL,
  `image_45` varchar(255) DEFAULT NULL,
  `image_46` varchar(255) DEFAULT NULL,
  `image_47` varchar(255) DEFAULT NULL,
  `image_48` varchar(255) DEFAULT NULL,
  `image_49` varchar(255) DEFAULT NULL,
  `image_50` varchar(255) DEFAULT NULL,
  `bg_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `cat_id`, `name`, `description`, `video`, `credits`, `quotes`, `news`, `awards`, `link`, `image_01`, `image_02`, `image_03`, `image_04`, `image_05`, `image_06`, `image_07`, `image_08`, `image_09`, `image_10`, `image_11`, `image_12`, `image_13`, `image_14`, `image_15`, `image_16`, `image_17`, `image_18`, `image_19`, `image_20`, `image_21`, `image_22`, `image_23`, `image_24`, `image_25`, `image_26`, `image_27`, `image_28`, `image_29`, `image_30`, `image_31`, `image_32`, `image_33`, `image_34`, `image_35`, `image_36`, `image_37`, `image_38`, `image_39`, `image_40`, `image_41`, `image_42`, `image_43`, `image_44`, `image_45`, `image_46`, `image_47`, `image_48`, `image_49`, `image_50`, `bg_image`, `created_at`, `updated_at`) VALUES
(1, 1, 'Architecture 01', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'videos/lTGRlR6EuFZIcLpkM2qZPGJRsUTsyatkSREybYqh.mp4', 'lorema sdsds', 'Lorem ipsum dolor', NULL, 'Lorem ipsum dolor', '/', '20230520180134.jpg', '0520180134.jpg', '20180134.png', '2320180134.jpg', '1801342023.jpg', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521144908.png', '20230521150022.png', '20230521150440.png', '20230521145626.png', '20230521145626.png', '20230521145626.png', '20230521145626.png', '20230521145626.png', '20230521145626.png', '20230521145626.png', '20230521145626.png', '20230521145626.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', '20230521145810.png', NULL, '2023-05-20 12:01:34', '2023-05-21 09:33:45'),
(5, 2, 'Construction 01', 'Construction 01', 'videos/JJncdRF19TtkN3EDtdmh9NMJ9LPvaxgwOozHAn00.mp4', NULL, NULL, NULL, NULL, NULL, '20230521151931.jpeg', '0521151931.jpeg', '21151931.jpeg', '2321151931.jpeg', '1519312023.jpeg', '20230521151931.jpeg', '0521151931.jpeg', '202321151931.jpeg', '202305151931.jpeg', '2023051931.jpeg', '2023052115.jpeg', '202305.jpeg', '1931.jpeg', '151931.jpeg', '2023.jpeg', '202331.jpeg', '31.jpeg', '2115.jpeg', '1531.jpeg', '21.jpeg', '05.jpg', '152207.jpg', '20232207.png', '2023152207.png', '202307.avif', '20230515.avif', '07202315.jfif', '070522.jpg', '2023052207.avif', '202305211523482023.jpg', '2023052115234815.jpg', '20230521152348May.png', '20230521152348Sun.png', '2023052115234815.avif', '2023052115234823.jfif', '2023052115234848.jpg', '2023052115234823.avif', '2220230521152422.png', '2320230521152348.jpg', '1520230521152348.jpg', '2120230521152348.png', '0520230521152348.avif', '2320230521152348.avif', '232320230521152348.jfif', '23232320230521152348.jpg', '050520230521152348.jpg', '05050520230521152348.jpg', '151520230521152348.png', '15152320230521152348.jfif', '15234820230521152348.jpg', NULL, '2023-05-21 09:19:31', '2023-05-21 09:28:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'admin@gmail.com', NULL, '$2y$10$cxG1WpP2B0CR0.ORteZC8uvY1pmd5s6i3ztt8zPLUz8NWr3Pq5fxO', NULL, '2023-05-20 02:10:02', '2023-05-20 02:10:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `basics`
--
ALTER TABLE `basics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `histories`
--
ALTER TABLE `histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ideas`
--
ALTER TABLE `ideas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offices`
--
ALTER TABLE `offices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `peoplecats`
--
ALTER TABLE `peoplecats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `basics`
--
ALTER TABLE `basics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `histories`
--
ALTER TABLE `histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ideas`
--
ALTER TABLE `ideas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `offices`
--
ALTER TABLE `offices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `peoplecats`
--
ALTER TABLE `peoplecats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
